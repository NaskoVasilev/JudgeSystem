//smaple solution comes here
using System;
class Program
{
}
	