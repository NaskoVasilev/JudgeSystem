class Test
{
	//write your php code here
}
