let sum = (a, b) => a + b;
let multiply = (a, b) => a * b;